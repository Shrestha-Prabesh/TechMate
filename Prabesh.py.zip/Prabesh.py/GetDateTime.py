import datetime

def getDate():
    Year = str(datetime.datetime.now().year)
    Month = str(datetime.datetime.now().month)
    Day = str(datetime.datetime.now().day)
   
    date = str(Year+"-"+Month+"-"+Day)
    return date

def getTime():
    
    Hour = str(datetime.datetime.now().hour)
    Minute = str(datetime.datetime.now().minute)
    Second = str(datetime.datetime.now().second)

    time = str(Hour+":"+Minute+":"+Second)
    return time 
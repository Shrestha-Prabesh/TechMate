import FileHandling


def getSN(LaptopData,transaction):
    """
    This function verifies that the user has entered a correct serial number or not.
    """
    correctSN = False

    while correctSN == False:
        print()
        try:
            SN = int(input("Enter the Serial Number of the laptops: "))

            if SN > 0 and SN <= len(LaptopData):
                
                quantity = int(LaptopData[SN][3])


                if transaction.lower() == 'Buy':

                    if quantity == 0:
                        
                        print()
                        print("-----------------------------------------------------------------------")
                        print("Sorry, The laptop are currently out of the stock. Please choose other laptops")
                        print("-----------------------------------------------------------------------")
                    
                    else:
                    
                        print()
                        print("-----------------------------------")
                        print("The laptop is avialable")
                        print("-----------------------------------")
                        print()
                        
                        return SN
                    
                else:

                    return SN
                        

            else:
                print()
                print("-------------------------------------------------------------------------")
                print("Invalid input!!!, Please enter the correct Serial Number and try again!!")
                print("-------------------------------------------------------------------------")

        except:
            print()
            print("---------------------------------------------------------")
            print("Invalid input!!!, Please enter the valid Serial Number")
            print("---------------------------------------------------------")


def getavailableQuantity(LaptopData, SN):
    """
    This function verifies that the user has entered a correct quantity or not.
    """
    availableQuantity = False

    while availableQuantity == False:
        print()
        try:
            quantity = int(input("Enter the total number of laptops that you want buy: "))

            if quantity > 0 and quantity <= int(LaptopData[SN][3]):

                LaptopData[SN][3] = str(int(LaptopData[SN][3]) - quantity)

                print()
                print("-----------------------------------------------------------------------")
                print("\t\tThank you for buying the laptop")
                print("-----------------------------------------------------------------------")
                
                return quantity

            elif quantity > int(LaptopData[SN][3]):
                print()
                print("------------------------------------------------------------------------------------------------")
                print("The quantity entered is greater than what we have in stock. Please check the available quantity and try again!!")
                print("------------------------------------------------------------------------------------------------")

            else:
                print()
                print("-------------------------------------------------------")
                print("Invalid Quantity!!!, Please enter the available quantity!!")
                print("-------------------------------------------------------")
                print()
        except:
            print()
            print("------------------------------------------------")
            print("Invalid input!!!, Please enter the valid input")
            print("------------------------------------------------")

def calculateTotalQuantity(LaptopData):
    '''
    This function calculates the total number of laptops that are currently availabe in the store
    '''

    totalQuantity = 0
    
    for SN in range(len(LaptopData)):
        SN = SN+1
       
        totalQuantity += int(LaptopData[SN][3])


    return totalQuantity

def removeDuplicateLaptops(store,SN,quantity):
    DuplicateLaptopsInStore = False
    
    for LaptopsDetails in store:
        
        if LaptopsDetails[0] == SN:
            LaptopsDetails[1] += quantity
            DuplicateLaptopsInStore = True

    if DuplicateLaptopsInStore == False:
        store.append([SN,quantity])

    return store

def BuyLaptop():
    """
    This function carries out all the necessary operations for the buying the laptops. 
    """
    print()
    print("------------------------------------------------------")
    print("\t\t Let's buy some laptops")
    print("------------------------------------------------------")
    print()
    
    continueLoop = True

    #Store the sold Laptops
    storesoldLaptops = []    
    
    while continueLoop:
        totalQuantity = calculateTotalQuantity(FileHandling.LaptopData)

        if totalQuantity == 0:

            if len(storesoldLaptops) == 0:
                
                print("------------------------------------------------------")
                print("We apologize. But we are out of stock at the moment.")
                print("------------------------------------------------------")
                

            else:
                FileHandling.generateBill(storesoldLaptops, FileHandling.LaptopData, "BUY", 0)
                storesoldLaptops.clear()

            continueLoop = False
        
        else:

            #Displaying all the Laptops details  
            print()
            FileHandling.printLaptops(FileHandling.LaptopData)

            #Serial number of Laptops
            SN = getSN(FileHandling.LaptopData, "BUY")

            #Quantity of available laptops
            quantity = getavailableQuantity(FileHandling.LaptopData, SN)

            #Removing the duplicate Laptops
            storesoldLaptops = removeDuplicateLaptops(storesoldLaptops,SN,quantity)
                    

            #Asking the user if they wants to buy multiple Laptops
            BuyMultipleLaptops = True
            
            while BuyMultipleLaptops:
                 
                print()
                UserInput = input("Would you like to buy more Laptops? y/n : ")
                UserInput = UserInput.lower()
                
                if UserInput == "n":
                    
                    FileHandling.generateBill(storesoldLaptops, FileHandling.LaptopData, "TechMate Sales Bill")
                    storesoldLaptops.clear()
                    
                    continueLoop = False
                    BuyMultipleLaptops = False
                
                elif UserInput == "y":
                    
                    BuyMultipleLaptops = False

                else:
                    print()
                    print("------------------------------------------------------")
                    print("Invalid input!!!, Please enter the valid input")
                    print("------------------------------------------------------")

            #Updating the text file
            FileHandling.updateFileStore(FileHandling.LaptopData)
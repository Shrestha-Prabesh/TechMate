
import FileHandling
import operations

def getReStockQuantity(LaptopData,SN):

    '''
    This function checks for quantity and other types of invalid inputs.
    '''
    continueLoop = True

    while continueLoop:
        try:
            
            totalQuantity = int(input("Enter the total number of laptops you want to re-stock: "))

            if totalQuantity > 0:
                LaptopData[SN][3] = str(int(LaptopData[SN][3]) + totalQuantity)
                
                return totalQuantity
            
            else:
                print()
                print("------------------------------------------------------")
                print("Invalid Quantity!!!, Please enter the valid quantity!!")
                print("------------------------------------------------------")
                print()

        except:
            print()
            print("------------------------------------------------------")
            print("Invalid input!!!, Please enter the valid input!!")
            print("------------------------------------------------------")
            print()


def reStockLaptop():
    '''
    This function carries out all the necessary operations for the re-stock of laptops. 
    '''
    print()
    print("------------------------------------------------------")
    print("\t\t Let's Re-Stock laptops")
    print("------------------------------------------------------")
    print()

    #Storing the Re-Stocked Laptops
    storeReStockedLaptops = []
    
    continueLoop = True
    
    while continueLoop:

        #Displaying all the Laptop details
        FileHandling.printLaptops(FileHandling.LaptopData)

        #Geting correct SN
        SN = operations.getSN(FileHandling.LaptopData, "Re-Stock")

        #Getting correct quantity while Re-Stocking
        totalQuantity = getReStockQuantity(FileHandling.LaptopData, SN)

        #Removing the duplicate values from the cart
        storeReStockedLaptops  = operations.removeDuplicateLaptops(storeReStockedLaptops ,SN,totalQuantity)

        #Asking the user whether he/she wants to Re-stock multiple Laptops
        ReStockMultipleLaptops = True
        
        while ReStockMultipleLaptops :
            
                print()
                userInput = input("Would you like to Re-stock more laptop? y/n : ")
                print()
                
                userInput = userInput.lower()
                
                if userInput == "n":

                    FileHandling.updateFileStore(FileHandling.LaptopData)
                    FileHandling.generateBill(storeReStockedLaptops, FileHandling.LaptopData, "TechMate Re-Stock Bill")
                    storeReStockedLaptops .clear()

                    ReStockMultipleLaptops  = False
                    continueLoop = False
                    
                
                elif userInput == "y":
                    ReStockMultipleLaptops  = False

                else:
                    print()
                    print("------------------------------------------------------")
                    print("Invalid input!!!, Please enter the valid input")
                    print("------------------------------------------------------")
#Importing the buy and restock modules
import operations
import ReStock
#printing welcome message for users
print()
print("-----------------------------------------------------------------------------------------------------------------------------------")
print()
print("\t\t\t\t\t\t\tWelcome to the TechMate!")
print("\t\t\t\t\t\t\t   Thankot, Kathmandu")
print("\t\t\t\t\t\t\t   Contact: 982347375")
print()
print("-----------------------------------------------------------------------------------------------------------------------------------")
print()
print("\t\tWelcome to out laptop store! We are passionate about providing our customers with the best laptops on the market.  ")
print("\tOur store features a diverse range of laptops,from sleek and portable models to powerful gaming machines. Our team is committed to help ")
print("\t\tyou find the perfect laptop that fits yot lifestyle and budget.Thankyou for choosing us as your go-to laptop store.")
print("-----------------------------------------------------------------------------------------------------------------------------------")
def welcomeMessage():
    """
    Here, the software,s options are shown, and the user inputs the options to perform operations appropriately, such as buying or re-stocking laptops.
    """
    while True:
        print()
        print("Select your option accordingly:")
        print()
        print("~> Press 1: To Buy a laptop.")
        print("~> Press 2: To Re-stock the laptop.")
        print("~> Press 3: To Exit.")

        print()
        userInput = input("Enter a Option: ")
        print()
        if(userInput == "1"):            
            operations.BuyLaptop()

        elif(userInput == "2"):
            ReStock.reStockLaptop()
            

        elif (userInput == "3"):
            print()
            print()
            print("\t\t\t\t\t Thank you for using our application!!")
            print()
            print()

            exit()

        else:
            print("Invalid input!!!")
            print("Please select the appropriate option from the options mentioned above and Try Again!!")
            print()

#This function displays the services that this program provide
welcomeMessage()
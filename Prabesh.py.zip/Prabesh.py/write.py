import GetDateTime
import FileHandling

def generateBill(cart, LaptopData, invoiceType):

    """
    Here the user name and contact information are obtained  and the total price and quantity are also determined.
    The for loop is uded to iterate through the 2D list.
    This also calls the function with the appropriatre parameter to generate a bill in a text file.
    """

    date = GetDateTime.getDate()
    time = GetDateTime.getTime()

    while True:
        
        print()
        customerName = input("Enter your Full Name: ")
        contactNumber = input("Enter your Contact Number: ")

        if customerName == '' or contactNumber == '':
            print()
            print("---------------------------------------------------------------------")
            print("Empty Fields!!, Please enter the customer name and phone number!!")
            print("---------------------------------------------------------------------")

        else:
            
            if contactNumber.isnumeric():
                
                break

            else:
                print()
                print("---------------------------------------------------------------------")
                print("Invalid Input!!!,Please check and re-enter phone number!!")
                print("---------------------------------------------------------------------")

    totalPrice = 0
    totalQuantity = 0
    VATamount = 0
    AmountAfterVAT = 0
    
    print()
    print()
    print("---------------------------------------------------------------------")
    print(f"\t\t\t {invoiceType}")
    print("---------------------------------------------------------------------")
    print()
    print("Name: ", customerName)
    print("Contact Number: ", contactNumber)
    print(f"Date of {invoiceType.lower()}: ", date)
    print("Time: ", time)


    print()
    print("---------------------------------------------------------------------------------")
    print("S.N", "\t", "Model", "\t\t\t","Specifications", "\t", "Price", "\t\t", "Quantity")
    print("---------------------------------------------------------------------------------")
  
    for index in range(len(cart)):
        
        SN = int(cart[index][0])
        quantity = cart[index][1]
        totalQuantity +=quantity
        
        LaptopName = LaptopData[SN][0]
        LaptopBrand = LaptopData[SN][1]
        price = float(LaptopData[SN][2].replace("$",""))

        totalPrice += (quantity * price)
        VATamount += (0.13 * totalPrice)
        AmountAfterVAT += (totalPrice + VATamount)


        print((index+1), "\t", LaptopName, "\t",LaptopBrand, "\t", "$" + str(price), "\t", quantity)

    print()
    print("Total Quantity: " + str(totalQuantity))
    print("Total: " + str(totalPrice))
    print("VAT percentage: 13%")
    print("VAT Amount: $" +str(VATamount))
    print("Grand Total: $" + str(AmountAfterVAT))

    print("-----------------------------------------------------------------------------------")

    FileHandling.generateBill(LaptopData,cart,customerName,contactNumber,totalPrice,totalQuantity, invoiceType,VATamount, AmountAfterVAT,time)
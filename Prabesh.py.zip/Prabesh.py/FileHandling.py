import GetDateTime

def getstore():
    """
    This function reads the laptop.txt file and returns the data of that file.
    """
    file = open("laptop.txt", "r")
    data = file.readlines()
    
    file.close()
    
    return data

def creatingDictionary(store):
    """
    The text file data that was obtained is properly stored in the dictionery.
    """
    dataInDictionary = {}

    for index in range(len(store)):
        
        dataInDictionary[index + 1] = store[index].replace("\n", "").split(",")
    
    return dataInDictionary

def updateFileStore(LaptopData):

    """
    This function will update the whenever the quantity changes.
    """
    file = open("laptop.txt", "w")
    for value in LaptopData.values():
        write_data = value[0] + "," + value[1] + "," + value[2] + "," + value[3] + "\n"
        file.write(write_data)
    file.close()

def generateBill(LaptopData, cart, customerName, contact, totalPrice, totalQuantity, AmountAfterVAT,VATamount, invoiceType,time):

    """
    The purpose of this function is to generate a text file and enter billing information.
    """
    time2 = time.replace(":","-")

    date = GetDateTime.getDate()

    file = open("Invoice/" + customerName + "_" + date + "_" + time2 + ".txt", "w")

    file.write("\n")
    file.write(f"** {invoiceType} INVOICE **\n")
    file.write("\n")
    file.write("Customer Name: " + customerName + "\n")
    file.write("Contact Number: " + contact + "\n")
    file.write(f"Date : " + date + "\n")
    file.write("Time: " + time + "\n")
    
    file.write("\n")
    
    file.write("Total Quantity: " + str(totalQuantity)+ "\n")
    file.write("Total: $" + str(totalPrice)+ "\n")
    file.write("VAT Amount: $" + str(VATamount))
    file.write("Grand Total : $" + str(AmountAfterVAT)+ "\n")
    
    file.write("\n")
    
    file.write("-------------------------------------------------------------------------------------------------\n")
    file.write("S.N" + "\t" + "Model" + "\t\t\t" + "Specifications" + "\t" + "Price" + "\t\t" + "Quantity" + "\n")
    file.write("-------------------------------------------------------------------------------------------------\n")

    for index in range(len(cart)):
        
        SN = int(cart[index][0])
        quantity = cart[index][1]
        
        LaptopName = LaptopData[SN][0]
        LaptopBrand = LaptopData[SN][1]
        price = LaptopData[SN][2]

        file.write(str(index+1) + "." + "\t" + LaptopName + "\t" + LaptopBrand + "\t\t" + price + "\t" + str(quantity) + "\n")

    file.write("-----------------------------------------------------------------------------------------\n")
   
    file.close()

def printLaptops(LaptopData):
    """
    Using a for loop, this function displays dictionery data  in a tabular manner.
    """
    print("-------------------------------------------------------------------------------")
    print("S.N", "\t", "Model", "\t\t\t","Specifications", "\t", "Price", "\t", "Quantity")
    print("-------------------------------------------------------------------------------")

    for key, value in LaptopData.items():
        print()
        print(key, "\t", value[0], "\t", value[1],"\t", value[2], "\t", value[3])

    print()
    print("-------------------------------------------------------------")

    return ""

#Reading the content of file
store = getstore()

#Storing the data of file in dictionary
LaptopData = creatingDictionary(store)